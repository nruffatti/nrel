# TgRhoP
Repo for predicting properities:
- Glass Transition (units = K)
- Density  (units = g/cm^3)
- Permeability (TBD)
